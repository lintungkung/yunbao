<?php
/**
 * PhalApi_Response_Explorer 控制台响应类
 *
 * @package     PhalApi\Response
 * @license     http://www.phalapi.net/license GPL 协议
 * @link        http://www.phalapi.net/
 * @author      dogstar <chanzonghuang@gmail.com> 2015-02-09
 */

class PhalApi_Response_Explorer extends PhalApi_Response {

    protected function formatResult($result) {

    }
}
