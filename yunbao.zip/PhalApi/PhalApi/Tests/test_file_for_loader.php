<?php
$testDataForLoader = array('msg' => 'Hello PhpUnit');
