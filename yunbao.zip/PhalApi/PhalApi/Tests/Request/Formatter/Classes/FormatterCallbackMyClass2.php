<?php
class FormatterCallbackMyClass2 {
    static function handle($var, $rule) {
        return $var . '_handle2';
    }
}

