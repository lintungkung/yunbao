<?php
class FormatterCallbackMyClass {
    static function handle($var, $rule) {
        return $var . '_handle';
    }
}

