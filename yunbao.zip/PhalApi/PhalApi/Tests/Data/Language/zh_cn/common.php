<?php

return array(
    'test' => 'this is a good way',
);
