<?php	return array (
  'cmf_admin_default_theme' => 'admin_simpleboot3',
);