module.exports = {
	'REDISHOST' : '127.0.0.1',
	'REDISPASS' : '',
	'REDISPORT' : '6379',
	'TOKEN'		: '1234567',
	'sign_key'	: '76576076c1f5f657b634e966c8836a06',
	'socket_port': '19967',
	'WEBADDRESS': 'http://xxxxx.com/appapi/'
}
